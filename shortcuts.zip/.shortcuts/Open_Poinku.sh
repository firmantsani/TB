su -c pm disable mypoin.indomaret.android >/dev/null 2>&1
su -c pm enable mypoin.indomaret.android >/dev/null 2>&1
su -c am start -n  mypoin.indomaret.android/mypoin.indomaret.android.ui.splash.SplashActivity >/dev/null 2>&1
exit
