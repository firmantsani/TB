su -c pm disable com.indomaret.klikindomaret >/dev/null 2>&1
su -c pm enable com.indomaret.klikindomaret >/dev/null 2>&1
su -c am start -n com.indomaret.klikindomaret/com.indomaret.klikindomaret.MainActivity >/dev/null 2>&1
exit
