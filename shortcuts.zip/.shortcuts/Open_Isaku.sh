su -c pm disable com.isaku.app >/dev/null 2>&1
su -c pm enable com.isaku.app >/dev/null 2>&1
su -c am start -n com.isaku.app/com.isaku.app.Activity.SplashScreen.SplashScreenActivity >/dev/null 2>&1
exit
