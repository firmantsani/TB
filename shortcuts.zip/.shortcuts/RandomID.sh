su -c cp /data/system/users/0/settings_ssaid.xml /data/local/tmp
#!/data/data/com.termux/files/usr/bin/bash
#bash cp.sh
ssaid=$(su -c cat /data/system/users/0/settings_ssaid.xml)
#echo "$ssaid"
##
poinku=$(echo "$ssaid" | grep -oP 'value="(.*)" package="mypoin.indomaret.android" defaultValue="(.*)" defaultSysSet="false"')
poinkuid=$(echo "$ssaid" | grep -oP 'package="mypoin.indomaret.android" defaultValue="(.*)" defaultSysSet="false"')
#idpoinku=$(echo $poinku | sed 's/value="//g' | sed 's/" package="mypoin.indomaret.android"//g' | sed 's/defaultValue="//g' | sed 's/" defaultSysSet="false"//g')
idpoinku=$(echo $poinkuid | sed 's/package="mypoin.indomaret.android" defaultValue="//g' | sed 's/" defaultSysSet="false"//g')
#devidpoinku=$(echo "$poinku" | grep -oP 'Value="(.*)" ')
#devidpoinku=$(echo "$devidpoinku" | grep -oP '"(.*)"')
devidpoinku=$idpoinku
echo "Device ID Poinku Lama : $devidpoinku"
#sleep 100
#cd Firman
#sh save.sh "$devidpoinku"
# > Firman/idpoin.txt
#echo "$devidpoinku"
##
klik=$(echo "$ssaid" | grep -oP 'value="(.*)" package="com.indomaret.klikindomaret" defaultValue="(.*)" defaultSysSet="false"')
klikid=$(echo "$ssaid" | grep -oP 'package="com.indomaret.klikindomaret" defaultValue="(.*)" defaultSysSet="false"')
#idpoinku=$(echo $poinku | sed 's/value="//g' | sed 's/" package="com.indomaret.klikindomaret"//g' | sed 's/defaultValue="//g' | sed 's/" defaultSysSet="false"//g')
idklik=$(echo $klikid | sed 's/package="com.indomaret.klikindomaret" defaultValue="//g' | sed 's/" defaultSysSet="false"//g')
devidklik=$idklik
#echo "$klik"
#printf "$devidklik" > idklik.txt
echo "Device ID Klik Lama : $devidklik"
#echo "$devidklik"
##
isaku=$(echo "$ssaid" | grep -oP 'value="(.*)" package="com.isaku.app" defaultValue="(.*)" defaultSysSet="false"')
isakuid=$(echo "$ssaid" | grep -oP 'package="com.isaku.app" defaultValue="(.*)" defaultSysSet="false"')
#idisaku=$(echo $isakuid | sed 's/value="//g' | sed 's/" package="com.isaku.app"//g' | sed 's/defaultValue="//g' | sed 's/" defaultSysSet="false"//g')
idisaku=$(echo $isakuid | sed 's/package="com.isaku.app" defaultValue="//g' | sed 's/" defaultSysSet="false"//g')
devidisaku=$idisaku
#echo "$isaku"
echo "Device ID I-Saku Lama : $devidisaku"
#printf "$devidisaku" > Firman/idisaku.txt
alfa=$(echo "$ssaid" | grep -oP 'value="(.*)" package="com.alfamart.alfagift" defaultValue="(.*)" defaultSysSet="false"')
alfaid=$(echo "$ssaid" | grep -oP 'package="com.alfamart.alfagift" defaultValue="(.*)" defaultSysSet="false"')
#idisaku=$(echo $isakuid | sed 's/value="//g' | sed 's/" package="com.isaku.app"//g' | sed 's/defaultValue="//g' | sed 's/" defaultSysSet="false"//g')
idalfa=$(echo $alfaid | sed 's/package="com.alfamart.alfagift" defaultValue="//g' | sed 's/" defaultSysSet="false"//g')
devidalfa=$idalfa
rm -f /storage/emulated/0/.cri 
#echo "$alfa"
echo "Device ID Alfagift Lama : $devidalfa"
#sh exec.sh $devidpoinku $devidklik $devidisaku
echo "~~~~~~~~~Mengacak Device ID~~~~~~~~~~~"
sleep 1
deviceid=$(cat /dev/urandom | tr -dc 'a-f0-9' | fold -w 16 | head -n 1)
echo "Device ID baru : $deviceid"
su -c sed -i "s/$devidpoinku/$deviceid/g" /data/local/tmp/settings_ssaid.xml
sleep 1
su -c sed -i "s/$idklik/$deviceid/g" /data/local/tmp/settings_ssaid.xml >/dev/null 2>&1
sleep 1
su -c sed -i "s/$idisaku/$deviceid/g" /data/local/tmp/settings_ssaid.xml >/dev/null 2>&1
sleep 1
su -c sed -i "s/$idalfa/$deviceid/g" /data/local/tmp/settings_ssaid.xml >/dev/null 2>&1
sleep 1
su -c cp /data/local/tmp/settings_ssaid.xml /data/system/users/0/settings_ssaid.xml >/dev/null 2>&1
echo "~~~~~~~~~Menyimpan Device ID~~~~~~~~~~"
echo ""
slot=$(su -c cat /data/data/com.keramidas.TitaniumBackup/shared_prefs/DataProfilesCache.xml | grep -oP 'currentProfile\"\>(.*)<\/string\>')
slot=$(echo $slot | sed 's/currentProfile">//g' | sed 's/<\/string>//g')
echo $deviceid > "/sdcard/firman/$slot.txt"
sleep 1
echo "Otomatis Merestart"
sleep 1
echo "Restart dalam 3"
sleep 1
echo "Restart dalam 2"
sleep 1
echo "Restart dalam 1"
sleep 1
su -c am start -a android.intent.action.REBOOT >/dev/null 2>&1
